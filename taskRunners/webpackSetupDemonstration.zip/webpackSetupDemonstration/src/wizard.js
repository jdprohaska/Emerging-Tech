export const wizard = {
    name: "Geoff",
    class: "wizard",
    race: "human",
    alignment: "lawful good",
    level: 6
};