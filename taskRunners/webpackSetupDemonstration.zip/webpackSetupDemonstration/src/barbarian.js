export const barbarian = {
    name: "Dave",
    class: "barbarian",
    race: "Orc",
    alignment: "chaotic good",
    level: 6
};