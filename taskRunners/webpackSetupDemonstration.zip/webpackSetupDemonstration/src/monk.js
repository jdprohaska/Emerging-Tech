export const monk = {
    name: "Lee",
    class: "monk",
    race: "Elf",
    alignment: "neutral good",
    level: 6
};