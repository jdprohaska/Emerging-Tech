export const fighter = {
    name: "John",
    class: "fighter",
    race: "dwarf",
    alignment: "true neutral",
    level: 6
};

